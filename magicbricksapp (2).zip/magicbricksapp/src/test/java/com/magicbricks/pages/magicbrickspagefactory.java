package com.magicbricks.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class magicbrickspagefactory {
	WebDriver driver;
    Actions actions;
    WebDriverWait wait;
    Robot robo;

//--------------------------------------Search ----------------------------//
	@FindBy(id="keyword")
	@CacheLookup
	WebElement search;
	
	@FindBy(xpath="//span[@class='placeHolderOut']")
	@CacheLookup
	WebElement res;
	
	@FindBy(xpath="//label[@id='11703']")
	@CacheLookup
	WebElement resbhk;
	
	@FindBy(xpath="//span[@id='rent_budget_lbl']")
	@CacheLookup
	WebElement bud;
	
	@FindBy(xpath="//*[@id=\"budgetMin\"]")
	@CacheLookup
	WebElement min;
	
	@FindBy(xpath="//*[@id=\"budgetMax\"]")
	@CacheLookup
	WebElement max;
	
	@FindBy(xpath="//*[@id=\"searchFormHolderSection\"]/section/div/div[1]/div[3]/div[4]")
	@CacheLookup
	WebElement searchbtn;
//-----------------------------------filter ------------------------------------------//
	@FindBy(xpath = "//*[@id=\"searchFormHolderSection\"]/section/div/div[1]/div[3]/div[4]")
	@CacheLookup
	WebElement searchfilter;
	
	@FindBy(xpath = "//*[@id=\"body\"]/div[1]/div/div[2]/div[1]/div/div[1]/div")
	WebElement topDrop;
	
	@FindBy(xpath = "//*[@id=\"body\"]/div[1]/div/div[2]/div[1]/div/div[2]/div[1]/div[2]/div[7]/label")
	WebElement loacli;
	
	@FindBy(xpath  = "//*[@id=\"body\"]/div[1]/div/div[2]/div[1]/div/div[2]/div[3]")
	WebElement localidone;
	
	@FindBy(xpath  = "/html/body/div/div[1]/div/div[2]/div[1]/div/div[2]/div[2]/div/div[1]/div")	
	WebElement Budeget2;
	
	@FindBy(xpath="//*[@id=\"body\"]/div[1]/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div[1]/select")
    WebElement postedbyOwner;
	
	@FindBy(xpath  = "//*[@id=\"body\"]/div[1]/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div[3]/select")
	WebElement Ownerdone;
	
	@FindBy(xpath  = "//*[@id=\"body\"]/div[1]/div/div[2]/div[6]/div/div[1]")
	WebElement morefilter;
	
	@FindBy(xpath  = "//*[@id=\"moreFilterTitle_8\"]")
	@CacheLookup
	WebElement OwnerShip;
	
	@FindBy(xpath  = "//*[@id=\"moreFilter_8\"]/div[2]/div[1]/label")
	@CacheLookup
	WebElement Freehold;
	
	@FindBy(className ="close_chat_box")
	WebElement chatclose;
	
	@FindBy(xpath  = "//*[@id=\"moreFilterTitle_10\"]")
	@CacheLookup
	WebElement Animities;
	
	@FindBy(className ="sb_yes_btn")
	WebElement chatcloseyes;
	 
	@FindBy(xpath  = "//*[@id=\"moreFilter_10\"]/div[2]/div[2]/div/label")
	@CacheLookup
	WebElement Lift;
		
	@FindBy(xpath  = "//*[@id=\"moreRefined\"]/div[3]/div/div[2]")
	@CacheLookup
	WebElement view;
//--------------------------------Sort ------------------------------------------//	
	@FindBy(xpath = "//*[@id=\"searchFormHolderSection\"]/section/div/div[1]/div[3]/div[4]")
	@CacheLookup
	WebElement Sortsearch;

	@FindBy(xpath = "//*[@id=\"body\"]/div[4]/div/div/div[1]/div[2]/div/div[1]")
	@CacheLookup
	WebElement clickonsort;

	@FindBy(xpath = "//*[@id=\"body\"]/div[4]/div/div/div[1]/div[2]/div/div[2]/ul/li[1]")
	@CacheLookup
	WebElement sortbyrevelence;

	@FindBy(xpath = "//*[@id=\"body\"]/div[4]/div/div/div[1]/div[2]/div/div[2]/ul/li[4]")
	@CacheLookup
	WebElement sortbyMostRecent;

	@FindBy(xpath = "//*[@id=\"body\"]/div[4]/div/div/div[1]/div[2]/div/div[2]/ul/li[5]")
	@CacheLookup
	WebElement sortbylowtohigh;
	
//---------------------------------Help Method-----------------------------------------//
	@FindBy(css ="#commercialIndex > header > section.mb-header__sub.active > div > ul > li:nth-child(7) > a")
	@CacheLookup
	WebElement help;

	@FindBy(css="#commercialIndex > header > section.mb-header__sub.active > div > ul > li:nth-child(7) > div > div > div > ul > li:nth-child(1) > a")
	@CacheLookup
	WebElement helpcenter;

	@FindBy(className ="md-close")
	@CacheLookup
	WebElement popupElement;

	@FindBy(xpath="//*[@id=\"searchContentInput\"]")
	@CacheLookup
	WebElement questions;

	@FindBy(id="searchContentInput")
	@CacheLookup
	WebElement typequery;

	@FindBy(xpath="//*[@id=\"doSearchButton\"]")
	@CacheLookup
	WebElement searchquery;

	@FindBy(xpath="//*[@id=\"searchResponse\"]/div[1]")
	@CacheLookup
	WebElement relatedquery;
//--------------------------------Request call Back----------------------------------//
	
	@FindBy(css ="#commercialIndex > header > section.mb-header__sub.active > div > ul > li:nth-child(7) > a")
	@CacheLookup
	WebElement helprequest;

	@FindBy(xpath ="//*[@id=\"commercialIndex\"]/header/section[2]/div/ul/li[7]/div/div/div/ul/li[2]/a")
	@CacheLookup
	WebElement salesenquirys;

	@FindBy(xpath ="//*[@id=\"b2cRequestCall\"]/div[2]")
	@CacheLookup
	WebElement requestcall;

	@FindBy(xpath="//input[@id='phoneNumber']")
	WebElement popupmobileno;

	@FindBy(xpath="//input[@id='email']")
	WebElement popupemail;


	@FindBy(xpath ="//input[@id='userName']")
	@CacheLookup
	WebElement popupname;

	@FindBy(xpath ="//select[@id='userType']")
	@CacheLookup
	WebElement popupowner;
	 
	@FindBy(xpath ="//*[@id=\"userType\"]/option[2]")
	@CacheLookup
	WebElement popupownerselect;

	@FindBy(xpath ="//*[@id=\"callBackSubmit\"]")
	@CacheLookup
	WebElement popupsubmit;
	
//-------------------------------------Search Methods---------------------------------//	
	public magicbrickspagefactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void launchsite() {
		driver.get("https://www.magicbricks.com/");
		}

	public void magicsearch(String key) {
		search.sendKeys(key);
		}
	
	public void residential() {
		actions = new Actions(driver);
		actions.moveToElement(res).click().build().perform();
		}
		
	public void residentialbhk() {
		actions = new Actions(driver);
		actions.moveToElement(resbhk).click().build().perform();
		}
	
	public void budget() {
		 actions = new Actions(driver); 
		 actions.moveToElement(bud).click().build().perform();
		 }
	public void minbudget(String key) {
	
		min.click();
		min.sendKeys(key);
		}
	public void maxbudget(String key) {
		max.click();
		max.sendKeys(key);
		}
	public void clicksearch() {
		searchbtn.click();
		}
	
//------------------------------------filter Methods-------------------------------------//
	


	
	public void launchsitefilter() {
		driver.get("https://www.magicbricks.com/");
		}
	
	public void searchfil(){
		actions = new Actions(driver); 
		actions.click(searchfilter).build().perform();
		}
	
	public void topLocality()  {
		
		actions = new Actions(driver); 
		actions.click(topDrop).build().perform();
		}
	
	public void locality() {
		actions = new Actions(driver); 
		actions.click(loacli).build().perform();
		}
	
	public void localitydone() {
		actions = new Actions(driver); 
		actions.click(localidone).build().perform();
		}

	public void minmaxbudget() {
		actions = new Actions(driver); 
		actions.click(Budeget2).build().perform();
		}

	public void postedOwner() throws AWTException, InterruptedException {
		actions = new Actions(driver); 
		actions.click(postedbyOwner).build().perform();
		robo=new Robot();
		Thread.sleep(1000);
		robo.keyPress(KeyEvent.VK_DOWN);
	    robo.keyPress(KeyEvent.VK_DOWN);
	    robo.keyPress(KeyEvent.VK_ENTER);
	    }
	
	public void postownerdone() {
		actions = new Actions(driver);
		actions.click(Ownerdone).build().perform();
		robo.keyPress(KeyEvent.VK_DOWN);
		robo.keyPress(KeyEvent.VK_DOWN);
		robo.keyPress(KeyEvent.VK_ENTER);
		}
	
	
	public void chatc() {
		 chatclose.click();
		 }
	
	public void chatccl() {
		 chatcloseyes.click();
		 }
	
	public void closelink() {
		driver.close();
		}
	
	public void morefilters() {
		actions = new Actions(driver); 
		actions.click(morefilter).build().perform();
		}
	
	public void OwnerSships() {
		actions = new Actions(driver); 
		actions.click(OwnerShip).build().perform();
		}
	
	public void Freeholds() {
		actions = new Actions(driver); 
		actions.click(Freehold).build().perform();
		}
	
	public void Animity() {
		actions = new Actions(driver); 
		actions.click(Animities).build().perform();
		}
	
	public void Lifts() {
		actions = new Actions(driver); 
		actions.click(Lift).build().perform();
		}
	
	public void viewprperty() {
		actions = new Actions(driver); 
		actions.click(view).build().perform();
		}

//-----------------------------------------sort Methods-------------------------------------//





public void launchsitesort() {
	driver.get("https://www.magicbricks.com/");
	}

public void searchsort(){
	wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	wait.until(ExpectedConditions.elementToBeClickable(Sortsearch));
	actions = new Actions(driver);
	actions.click(Sortsearch).build().perform();
	}

public void clicksort(){
	actions = new Actions(driver); 
	actions.click(clickonsort).build().perform();
	}

public void scroll() throws AWTException, InterruptedException {
    Robot robot = new Robot();
    for (int i = 0; i < 3; i++) {
    	robot.keyPress(KeyEvent.VK_DOWN);
    	robot.keyRelease(KeyEvent.VK_DOWN);
    	Thread.sleep(4000);
    	}
}
public void relevence(){
	actions = new Actions(driver); 
	actions.click(sortbyrevelence).build().perform();
	}

public void mostRecent() throws InterruptedException{
	actions = new Actions(driver); 
	actions.click(sortbyMostRecent).build().perform();
	}

public void lowtohigh() throws  InterruptedException{
	actions = new Actions(driver); 
	actions.click(sortbylowtohigh).build().perform();
	
	}

//---------------------------------Help Methods------------------------------------------//



public void launchsitehelp() {
	driver.get("https://www.magicbricks.com/");

	}

public void magichelp() {
	actions = new Actions(driver);
	actions.moveToElement(help).perform();
	}

public void magichelpcenter() throws InterruptedException {
	 JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
	 jsExecutor.executeScript("arguments[0].click();", helpcenter);
	 Thread.sleep(1000);
	 String parentWindowHandle = driver.getWindowHandle();
	 for (String windowHandle : driver.getWindowHandles()) {
		 if (!windowHandle.equals(parentWindowHandle)) {
			 driver.switchTo().window(windowHandle);
			 break;
			 }
		 }
	 }

public void popup() throws InterruptedException  {
	wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	wait.until(ExpectedConditions.elementToBeClickable(popupElement));
	popupElement.click();
	Thread.sleep(1000);
	}

public void query() {
	actions = new Actions(driver);
	actions.click(questions).build().perform();
	}

public void typequestion(String key) throws InterruptedException {
	typequery.sendKeys(key);
	Thread.sleep(3000);
	}
public void seachquerybtn() throws InterruptedException {
	JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
    jsExecutor.executeScript("arguments[0].click();", searchquery);
    }

public void relatedquerybtn() throws InterruptedException {
	wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	wait.until(ExpectedConditions.elementToBeClickable(relatedquery));
	JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
    jsExecutor.executeScript("arguments[0].click();", relatedquery);
    }

//------------------------------Request call by methods---------------------------------//

 public void launchsiterequest() {
	 driver.get("https://www.magicbricks.com/");
	 }
 
public void magichelprequest() {
	actions = new Actions(driver);
	actions.moveToElement(helprequest).perform();
	}

public void salenquirys()  {
	actions = new Actions(driver);
	actions.click(salesenquirys).build().perform();
	}


public void requestcallback() throws InterruptedException  {
	Thread.sleep(2000);
	String parentWindowHandle = driver.getWindowHandle();
	for (String windowHandle : driver.getWindowHandles()) {
		if (!windowHandle.equals(parentWindowHandle)) {
			driver.switchTo().window(windowHandle);
			break;
			}
		}
	actions = new Actions(driver);
	actions.click(requestcall).build().perform();
	}


public void requestcallbackpopup(String name, String mobileno ,String email) throws InterruptedException, AWTException {
	popupname.sendKeys(name);
	popupmobileno.sendKeys(mobileno);
	popupemail.sendKeys(email);
	popupowner.click();
	Thread.sleep(1000);
	robo=new Robot();
	Thread.sleep(1000);
	robo.keyPress(KeyEvent.VK_DOWN);
	robo.keyPress(KeyEvent.VK_ENTER);
	}


public void clickrequest() throws InterruptedException {
	wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	wait.until(ExpectedConditions.elementToBeClickable(popupsubmit));
	popupsubmit.click();
	}
			
			
		
}

