package com.magicbricks.utils;



import org.openqa.selenium.WebDriver;

import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;



public class SetupDriver {
	public static WebDriver driver;
	public static EdgeOptions options;
	
	public static WebDriver Edgedriver() {

        driver = new EdgeDriver();
        driver.navigate().refresh();
        driver.get("https://www.magicbricks.com/");
   
        
        driver.manage().window().maximize();

        options= new EdgeOptions();

        

        options.addArguments("--start-maximized");

        options.addArguments("--disable-popup-blocking");

        options.addArguments("--disable-notifications");

        //driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(5));

        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        return driver;

    }
	
	public static void teardown() {
		driver.quit();
	}
	
}
