package com.magicbricks.stepdefinition;

import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import com.magicbricks.pages.magicbrickspagefactory;
import com.magicbricks.utils.Capture_Screenshot;
import com.magicbricks.utils.SetupDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class magicbricksStepdefination {
	WebDriver driver=SetupDriver.Edgedriver();
	magicbrickspagefactory magicbricksapp= new magicbrickspagefactory(driver);;
//----------------------------Tag 1 Search Step definition----------------------//
	@Given("user is on magicbricks homepage")	
	public void user_is_on_magicbricks_homepage() {
		magicbricksapp.launchsite();
	}
	@When("^user enter (.*) into the search fields$")
	public void user_enter_into_the_search_fields(String string) throws InterruptedException{
		magicbricksapp.magicsearch("Mumbai");
		Thread.sleep(1000);
	}
	@And("user clicks on dropdown box residential")
	public void user_clicks_on_dropdown_box_residential() throws InterruptedException {
		magicbricksapp.residential();
		Thread.sleep(1000);
	}
	@And("user select option from dropdown box")
	public void user_select_option_from_dropdown_box() throws InterruptedException {
		magicbricksapp.residentialbhk();
		Thread.sleep(1000);
	}
	@And("user click on budget dropdown")
	public void user_click_on_budget_dropdown() throws InterruptedException {
		magicbricksapp.budget();
		Thread.sleep(1000);
	}
	@And("user enter keys, min_price,max_prize")
	public void user_enter_keys_min_price_max_prize(io.cucumber.datatable.DataTable keyword) {
		List<String> cells=keyword.asList(String.class);
		magicbricksapp.minbudget(cells.get(0));
		magicbricksapp.maxbudget(cells.get(1));
	}
	@And("user clicks on search button")
	public void user_clicks_on_search_button() {
		magicbricksapp.clicksearch();
		
	}
	@Then("search should show results")
	public void search_should_show_results() throws IOException, InterruptedException {
		WebElement verify =driver.findElement(By.xpath("//*[@id=\"propertysrp\"]/div[1]/div/div/div[1]/div[1]/a"));
	    boolean b=verify.isEnabled();
	    Assert.assertEquals(true,b);
	    Capture_Screenshot.capture(driver);
	    Thread.sleep(3000);
	    driver.close();  
	    }
	
//-----------------------------------------------------------------------------------

	
	
	
	@Given("user is on magicbricks search result page")
	public void user_is_on_magicbricks_search_result_page() {
		magicbricksapp.launchsitefilter();
		magicbricksapp.searchfil();
	}
	@When("user should click on Top locality filter dropdown")
	public void user_should_click_on_top_locality_filter_dropdown() throws InterruptedException {
		magicbricksapp.topLocality();
		Thread.sleep(2000);
	}
	@And("user should click on area")
	public void user_should_click_on_area() throws InterruptedException {
		magicbricksapp.locality();
		Thread.sleep(2000);
		magicbricksapp.localitydone();
	}
	@And("user clicks on more filters from the dropdown")
	public void user_clicks_on_more_filters_from_the_dropdown() throws InterruptedException {
		magicbricksapp.morefilters();
	   Thread.sleep(2000);
	   
	}
	@And("user clicks on ownwership")
	public void user_clicks_on_ownwership() throws InterruptedException {
	    magicbricksapp.OwnerSships();
	    Thread.sleep(2000);
	    magicbricksapp.Freeholds();
	}
	@And("user clicks on Lift checkbox")
	public void user_clicks_on_lift_checkbox() throws InterruptedException {
		magicbricksapp.Animity();
	   Thread.sleep(2000);
	   magicbricksapp.Lifts();
	}
	@And("user clicks on view properties")
	public void user_clicks_on_view_properties() throws InterruptedException {
		Thread.sleep(2000);
		magicbricksapp.viewprperty();
	   
	}
	@Then("search should show results from more filters")
	public void search_should_show_results_from_more_filters() throws IOException, InterruptedException {
		WebElement verifyfilter =driver.findElement(By.xpath("//*[@id=\"body\"]/div[1]/div/div[2]/div[2]/div/div[1]/div"));
	    boolean b=verifyfilter.isEnabled();
	    Assert.assertEquals(true,b);
	    Capture_Screenshot.capture(driver);
	    Thread.sleep(3000);
	    driver.close();  
	   
	}
	
//-------------------------------------------------------------------------------------
	//SortPagefactory so= new SortPagefactory(driver);
	@Given("user is on search results page")
	public void user_is_on_search_results_page() {
		magicbricksapp.launchsitesort();
		magicbricksapp.searchsort();
	}
	@When("user clicks on sort functionality")
	public void user_clicks_on_sort_functionality() throws InterruptedException, AWTException {
	   Thread.sleep(2000);
	   magicbricksapp.clicksort();
		Thread.sleep(2000);
		magicbricksapp.relevence();
		Thread.sleep(2000);
		magicbricksapp.clicksort();
		Thread.sleep(2000);
		magicbricksapp.mostRecent();
		Thread.sleep(2000);
		magicbricksapp.clicksort();
		Thread.sleep(2000);
		magicbricksapp.lowtohigh();
		Thread.sleep(2000);
		magicbricksapp.scroll();
	}
	@Then("sorted results should be shown")
	public void sorted_results_should_be_shown() throws IOException, InterruptedException {
		WebElement verify =driver.findElement(By.xpath("//*[@id=\"body\"]/div[4]/div/div/div[1]/div[2]/ul/li[1]"));
	    boolean b=verify.isEnabled();
	    Assert.assertEquals(true,b);
	    Capture_Screenshot.capture(driver);
	    Thread.sleep(3000);
	    driver.close();  
	  
	}
	
//-------------------------------------------------------------------------------------------------------------------	

	//HelpPagefactory h= new HelpPagefactory(driver);;
	
	@Given("user is on magicbricks Home page")
	public void user_is_on_magicbricks_home_page() {
		magicbricksapp.launchsitehelp();
	}
	@When("user mouseover on help functionality")
	public void user_mouseover_on_help_functionality() throws InterruptedException {
		Thread.sleep(1000);
		magicbricksapp.magichelp();
	}
	@And("user should click on help center")
	public void user_should_click_on_help_center() throws InterruptedException {
		
		
		magicbricksapp.magichelpcenter();
	    Thread.sleep(9000);
	    
	    magicbricksapp.popup();
	    
	
	}
	@And("^user enter question(.*)$")
	public void user_enter_question(String string) throws InterruptedException {
	
		magicbricksapp.query();
		Thread.sleep(2000);
		magicbricksapp.typequestion(string);
	}
	@And("user should click on search button")
	public void user_should_click_on_search_button() throws InterruptedException {
		Thread.sleep(1000);
		magicbricksapp.seachquerybtn();
		magicbricksapp.relatedquerybtn();
	}
	@Then("results should be for help")
	public void results_should_be_for_help() throws IOException, InterruptedException {
		WebElement verifyhelp =driver.findElement(By.xpath("/html/body/header/div/div[1]/a"));
	    boolean b=verifyhelp.isEnabled();
	    Assert.assertEquals(true,b);
	    Capture_Screenshot.capture(driver);
	    Thread.sleep(3000);
	    driver.close();
	}
//-------------------------------------------request call back--------------------------------//	
	
	
	
	@Given("user is on magic bricks home page")
	public void user_is_on_magic_bricks_home_page() {
	magicbricksapp.launchsiterequest();
	
	}
	
	@When("user click on sales the Enquiry")
	public void user_click_on_sales_the_enquiry() {
	 magicbricksapp.magichelprequest();
	 magicbricksapp.salenquirys();
	 }
	
	
	@And("user click on request call back")
	public void user_click_on_request_call_back() throws InterruptedException {
		magicbricksapp.requestcallback();
		}
	@And("user enter name & mobile_no & email")
	public void user_enter_name_mobile_no_email() throws InterruptedException, IOException, AWTException {
		File file= new File("C:\\Users\\sgondole\\eclipse-workspace\\magicbricksapp\\ExcelData\\data1.xlsx");
		FileInputStream fos = new FileInputStream(file);
		Workbook w = new XSSFWorkbook(fos);
		Sheet s = w.getSheetAt(0);
		String username = s.getRow(0).getCell(0).getStringCellValue();
		String mobileno =(String.valueOf((long)(s.getRow(0).getCell(1).getNumericCellValue())));
		String email =s.getRow(0).getCell(2).getStringCellValue();
		magicbricksapp.requestcallbackpopup(username, mobileno, email);
	}


    @And("user click on request a call")
    public void user_click_on_request_a_call() throws InterruptedException {
    	magicbricksapp.clickrequest();
    	}
    
    @Then("request call back should be sent")
    public void request_call_back_should_be_sent() throws IOException, InterruptedException {
    	WebElement verifyRequestcallback =driver.findElement(By.xpath("//*[@id=\"inbound-form__thanks\"]"));
    	boolean b=verifyRequestcallback.isEnabled();
    	Assert.assertEquals(true,b);
    	Capture_Screenshot.capture(driver);
    	Thread.sleep(4000);
	    driver.close();
    	}


}
